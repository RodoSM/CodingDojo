var me_gusta1 = 9;

function like1() {
    me_gusta1++;
    var cantidad1 = document.querySelector("#count1"); 
    cantidad1.innerText = me_gusta1;
}

function dislike1() {
    me_gusta1--;
    var cantidad1 = document.querySelector("#count1"); 
    cantidad1.innerText = me_gusta1;
}

var me_gusta2 = 12;

function like2() {
    me_gusta2++;
    var cantidad2 = document.querySelector("#count2"); 
    cantidad2.innerText = me_gusta2;
}

function dislike2() {
    me_gusta2--;
    var cantidad2 = document.querySelector("#count2"); 
    cantidad2.innerText = me_gusta2;
}


var me_gusta3 = 9;

function like3() {
    me_gusta3++;
    var cantidad3 = document.querySelector("#count3"); 
    cantidad3.innerText = me_gusta3;
}

function dislike3() {
    me_gusta3--;
    var cantidad3 = document.querySelector("#count3"); 
    cantidad3.innerText = me_gusta3;
}

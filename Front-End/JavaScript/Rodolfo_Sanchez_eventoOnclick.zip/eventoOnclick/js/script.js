

function cambiar_texto(elemento){
    elemento.innerText = "Logout";
}

function eliminar(elemento){
    elemento.remove();
}

function alerta(){
    alert("Ninja was Liked!");
}